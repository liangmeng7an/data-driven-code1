clear all;clc;% M 文件内容


% 打开 Simulink 模型
open_system('qiehun1');

% 设置仿真参数（如果需要）
% 例如，设置仿真开始和结束时间
set_param('qiehun1', 'StopTime', '40'); % 仿真将在40秒后停止
set_param('qiehun1', 'StartTime', '0'); % 仿真从0秒开始

% 运行仿真
simOut = sim('qiehun1');
%记录数据
DATA1 = simOut.ScopeData;

t=DATA1(:,1);X=DATA1(:,[2 3]);
Z = DATA1(:,4);

subplot(2,1,1)
plot(t,X,t,Z,'LineWidth', 0.8);
title('Switched system');
axis([0 40 -1 3.5])
xlabel('t/s');
ylabel('x(t)');
legend('x_{1}', 'x_{2}','Upper Bound','Location','NorthEast');
grid on;



% axes('position',[0.31 0.55 0.58 0.33]);
subplot(2,1,2)
y1=1.*(t>=0&t<2)+2.*(t>=2&t<3)+1.*(t>=3&t<5)+2.*(t>=5&t<13)+1.*(t>=13&t<17)+2.*(t>=17&t<22)+1.*(t>=22&t<26)+2.*(t>=26&t<31)+1.*(t>=31&t<35)+2.*(t>=35);
y2=1.*(t>=0&t<2.1)+2.*(t>=2.1&t<3.1)+1.*(t>=3.1&t<5.1)+2.*(t>=5.1&t<13.1)+1.*(t>=13.1&t<17.1)+2.*(t>=17.1&t<22.1)+1.*(t>=22.1&t<26.1)+2.*(t>=26.1&t<31.1)+1.*(t>=31.1&t<35.1)+2.*(t>=35.1);
% figure('position',[0,0,700,300])
plot(t,y1,'r--',t,y2,'b','linewidth',0.4);
xlabel('t/s');
h=legend('$\sigma(t)$','$\sigma^{\prime}(t)$','Location','NorthEast');
set(h,'Interpreter','Latex','fontsize',10);
grid on;
xlabel('t/s');
ylabel('System modes');
title('Switched signal');
axis([0 40 0.5 3])

zp = BaseZoom();
zp.run























