clear all;clc;% M 文件内容


% 打开 Simulink 模型
open_system('system3');

% 设置仿真参数（如果需要）
% 例如，设置仿真开始和结束时间
set_param('system3', 'StopTime', '50'); % 仿真将在50秒后停止
set_param('system3', 'StartTime', '0'); % 仿真从0秒开始

% 运行仿真
simOut = sim('system3');
%记录数据
DATA1 = simOut.ScopeData;
 test_data_T = DATA1([1 2 5 14 43],:);%数据的转置
 test_data1 = test_data_T';

DATA2 = simOut.ScopeData1;
 test_data_T2 = DATA2([1 2 5 14 43],:);%数据的转置
 test_data2 = test_data_T2';


%检验行满秩条件
Rank = rank(test_data1);

Rank2 = rank(test_data2);
% 定义已知的数据矩阵
X_D1 = test_data1([2;3],:);
U_D1 = test_data1(1,:);

X_D2 = test_data2([2;3],:);
U_D2 = test_data2(1,:);

[m,T] = size(X_D1);


A1 = [0 1;0 -3.2]; A2 = [0 1;0 -0.5];             %定义子系统的A

B1 = [0;0.6];B2 = [0;0.1];          %定义子系统的B

for i = 1:T

    g = U_D1(1,i);

    r(:,i) = 0.1*[rand(1,1)-0.5;rand(1,1)-0.5];

    D(:,i) = 0.5*[0.1*sin(g);0.1*cos(g)];

    XX11(:,i) = A1*X_D1(:,i)+B1*U_D1(:,i) + D(:,i) + r(:,i);

    XX22(:,i) = A2*X_D2(:,i)+B2*U_D2(:,i) + D(:,i) + r(:,i);

    XX12(:,i) = A1*X_D2(:,i)+B1*U_D2(:,i) + D(:,i) + r(:,i);

    XX21(:,i) = A2*X_D1(:,i)+B2*U_D1(:,i) + D(:,i) + r(:,i);
end
% 
% XX11= A1*X_D1+B1*U_D1 + 0.1*sin(U_1);   % 产生同步矩阵，p=11，XX11代表导数
% 
% XX22= A2*X_D2+B2*U_D2 + 0.1*cos(U_2);    % 产生同步矩阵，q=22
% 
% XX12= A1*X_D2+B1*U_D2 + 0.1*sin(U_2);      %产生异步矩阵，pq =12
% 
% XX21= A2*X_D1+B2*U_D1 + 0.1*cos(U_1);      %产生异步矩阵，qp =21
% 
%定义定理1中的正的常数

L = 30;

lambda_s = 0.3;

lambda_u = 0.1;

u=1.1;

ep = 1;      %即epsilon，为了简写

a = 0.000001;     %由于对称矩阵产生的约束

delta_2 = 2*(0.05^2*2*5*eye(2));

% 创建一个新的 LMI 系统
setlmis([]);

% 定义矩阵变量，为了方便计算，此处仅定义两个变量，Y1和Y2，Y1 = Y21, Y2 = Y12  

Y1 = lmivar(2, [T m]);

Y2 = lmivar(2, [T m]);

%约束条件，正定性约束

lmiterm([-1 1 1 Y1], X_D1, 1);

lmiterm([-2 1 1 Y2], X_D2, 1);

%对称性约束，X1Y1 = X1Y1^{T}

lmiterm([3 1 1 0], -a*eye(m));

lmiterm([3 1 2 Y1], X_D1, 1);

lmiterm([3 1 2 -Y1], -1, X_D1');

lmiterm([3 2 2 0], -eye(m));

%X2Y2 = X2Y2^{T}

lmiterm([4 1 1 0], -a*eye(m));

lmiterm([4 1 2 Y2], X_D2, 1);

lmiterm([4 1 2 -Y2], -1, X_D2');

lmiterm([4 2 2 0], -eye(m));

%切换点产生的约束

lmiterm([5 1 1 Y2], X_D2, 1);

lmiterm([5 1 1 Y1], X_D1, -u);

lmiterm([6 1 1 Y1], X_D1, 1);

lmiterm([6 1 1 Y2], X_D2, -u);

%同步产生的约束，第一个系统

lmiterm([7 1 1 Y1], XX11, 1);

lmiterm([7 1 1 -Y1], 1, XX11');

lmiterm([7 1 1 Y1], X_D1, lambda_s);

lmiterm([7 1 1 0], ep*delta_2);

lmiterm([7 1 2 0], eye(m));

lmiterm([7 1 3 -Y1], 1, 1);

lmiterm([7 2 2 0], -L*eye(m));

lmiterm([7 3 3 0], -ep*eye(T));

%第二个系统

lmiterm([8 1 1 Y2], XX22, 1);

lmiterm([8 1 1 -Y2], 1, XX22');

lmiterm([8 1 1 Y2], X_D2, lambda_s);

lmiterm([8 1 1 0], ep*delta_2);

lmiterm([8 1 2 0], eye(m));

lmiterm([8 1 3 -Y2], 1, 1);

lmiterm([8 2 2 0], -L*eye(m));

lmiterm([8 3 3 0], -ep*eye(T));

%考虑系统异步产生的约束，pq=12

lmiterm([9 1 1 Y2], XX12, 1);

lmiterm([9 1 1 -Y2], 1, XX12');

lmiterm([9 1 1 Y2], X_D2, -lambda_u);

lmiterm([9 1 1 0], ep*delta_2);

lmiterm([9 1 2 0], eye(m));

lmiterm([9 1 3 -Y2], 1, 1);

lmiterm([9 2 2 0], -L*eye(m));

lmiterm([9 3 3 0], -ep*eye(T));

%qp = 21

lmiterm([10 1 1 Y1], XX21, 1);

lmiterm([10 1 1 -Y1], 1, XX21');

lmiterm([10 1 1 Y1], X_D1, -lambda_u);

lmiterm([10 1 1 0], ep*delta_2);

lmiterm([10 1 2 0], eye(m));

lmiterm([10 1 3 -Y1], 1, 1);

lmiterm([10 2 2 0], -L*eye(m));

lmiterm([10 3 3 0], -ep*eye(T));


lmiterm([11 1 1 Y1], X_D1, 1);
lmiterm([11 1 1 0], -1.65*eye(2));




% 获取 LMI 系统
lmis = getlmis;

% 求解 LMI 系统
[tmin, xfeas] = feasp(lmis);

Y_1 = dec2mat(lmis, xfeas, Y1);
Y_2 = dec2mat(lmis, xfeas, Y2);

K1 = U_D1*Y_1*pinv(X_D1*Y_1)
K2 = U_D2*Y_2*pinv(X_D2*Y_2)


X1Y1 = X_D1*Y_1
X2Y2 = X_D2*Y_2

zeta = max(eig(X1Y1), eig(X2Y2))

zz = max(zeta)

x0 = [-1,1];

xishu = (zz)^0.5*1.1^(0.0125)*(x0*inv(X1Y1)*x0'-((30)^(0.5)*(0.005)^(0.5))/(0.25-2*log(1.1)/4)^(0.5))^(0.5)

jie = (zz)^0.5*1.1^(0.0125)*((30)^(0.5)*(0.005)^(0.5))/(0.25-2*log(1.1)/4)^(0.5)

 % eig(A1+B1*K1)
% eig(XX11*Y_1*pinv(X_D1*Y_1))
 % eig(A2+B2*K2)
% eig(XX22*Y_2*pinv(X_D2*Y_2))

